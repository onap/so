#!/usr/bin/python

import sys
from HeatBridge import HeatBridge

#print len(sys.argv);

if (len(sys.argv)<8):
    print "Usage: " + sys.argv[0] + " openstack_identity_url username password tenant region owner heat_stack_id";
    sys.exit(1);
else:
    openstack_identity_url = sys.argv[1];
    username = sys.argv[2];
    password = sys.argv[3];
    tenant = sys.argv[4];
    region = sys.argv[5];
    owner = sys.argv[6];
    heat_stack_id = sys.argv[7];
    
    print("owner / heatstack id: " + owner + " / "  + heat_stack_id);
    
    hb = HeatBridge();
    hb.init_bridge(openstack_identity_url, username, password, tenant, region, owner);
    hb.bridge_data(heat_stack_id);
    sys.exit(0);
