class heatbridge:
    
    def __init__(self):
        pass;
